package com.example.bookstore.controller;

import com.example.bookstore.model.Book;
import com.example.bookstore.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED) // Sets the response status to 201 Created
    public Book createBook(@RequestBody Book book) {
        return bookService.saveBook(book);
    }

    // Other endpoints like GET, PUT, DELETE can be added here
}
