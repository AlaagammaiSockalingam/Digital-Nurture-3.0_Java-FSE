package com.example.bookstore.health;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component
public class CustomHealthIndicator implements HealthIndicator {

    @Override
    public Health health() {
        // Custom health check logic
        boolean isHealthy = true; // Replace with actual health check
        if (isHealthy) {
            return Health.up().withDetail("Custom", "All systems operational").build();
        } else {
            return Health.down().withDetail("Custom", "Service unavailable").build();
        }
    }
}
