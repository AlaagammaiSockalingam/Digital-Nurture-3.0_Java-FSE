package com.example.bookstore.controller;

import com.example.bookstore.assembler.BookResourceAssembler;
import com.example.bookstore.dto.BookDTO;
import com.example.bookstore.model.Book;
import com.example.bookstore.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/books")
@Validated
public class BookController {

    @Autowired
    private BookService bookService;

    @Autowired
    private BookResourceAssembler bookResourceAssembler;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EntityModel<BookDTO> createBook(@Valid @RequestBody Book book) {
        BookDTO bookDTO = convertToDTO(bookService.createBook(book));
        return bookResourceAssembler.toModel(bookDTO);
    }

    @GetMapping
    public List<EntityModel<BookDTO>> getAllBooks() {
        List<BookDTO> bookDTOs = bookService.getAllBooks().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
        return bookDTOs.stream()
                .map(bookResourceAssembler::toModel)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<BookDTO>> getBookById(@PathVariable("id") @NotNull Long id) {
        Optional<Book> book = bookService.getBookById(id);
        return book.map(b -> ResponseEntity.ok(bookResourceAssembler.toModel(convertToDTO(b))))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<BookDTO>> updateBook(@PathVariable("id") @NotNull Long id,
            @Valid @RequestBody Book book) {
        Book updatedBook = bookService.updateBook(id, book);
        BookDTO bookDTO = convertToDTO(updatedBook);
        return ResponseEntity.ok(bookResourceAssembler.toModel(bookDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable("id") @NotNull Long id) {
        bookService.deleteBook(id);
        return ResponseEntity.noContent().build();
    }

    private BookDTO convertToDTO(Book book) {
        return new BookDTO(book.getId(), book.getTitle(), book.getAuthor(), book.getPrice());
    }
}
