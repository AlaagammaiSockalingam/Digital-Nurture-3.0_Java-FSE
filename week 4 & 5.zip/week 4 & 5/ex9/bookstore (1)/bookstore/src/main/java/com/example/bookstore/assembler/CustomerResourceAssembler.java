package com.example.bookstore;

import com.example.bookstore.controller.CustomerController;
import com.example.bookstore.dto.CustomerDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.stereotype.Component;

@Component
public class CustomerResourceAssembler {

    public EntityModel<CustomerDTO> toModel(CustomerDTO customerDTO) {
        // Create self-link
        Link selfLink = WebMvcLinkBuilder
                .linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class).getCustomerById(customerDTO.getId()))
                .withSelfRel();

        // Create all-customers link
        Link allCustomersLink = WebMvcLinkBuilder
                .linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class).getAllCustomers())
                .withRel("all-customers");

        // Build the EntityModel
        return EntityModel.of(customerDTO, selfLink, allCustomersLink);
    }
}
