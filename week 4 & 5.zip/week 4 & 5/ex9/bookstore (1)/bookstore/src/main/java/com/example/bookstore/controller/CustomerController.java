package com.example.bookstore.controller;

import com.example.bookstore.assembler.CustomerResourceAssembler;
import com.example.bookstore.dto.CustomerDTO;
import com.example.bookstore.model.Customer;
import com.example.bookstore.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/customers")
@Validated
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @Autowired
    private CustomerResourceAssembler customerResourceAssembler;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EntityModel<CustomerDTO> createCustomer(@Valid @RequestBody Customer customer) {
        CustomerDTO customerDTO = convertToDTO(customerService.createCustomer(customer));
        return customerResourceAssembler.toModel(customerDTO);
    }

    @GetMapping
    public List<EntityModel<CustomerDTO>> getAllCustomers() {
        List<CustomerDTO> customerDTOs = customerService.getAllCustomers().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
        return customerDTOs.stream()
                .map(customerResourceAssembler::toModel)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<CustomerDTO>> getCustomerById(@PathVariable("id") @NotNull Long id) {
        Optional<Customer> customer = customerService.getCustomerById(id);
        return customer.map(c -> ResponseEntity.ok(customerResourceAssembler.toModel(convertToDTO(c))))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<CustomerDTO>> updateCustomer(@PathVariable("id") @NotNull Long id,
            @Valid @RequestBody Customer customer) {
        Customer updatedCustomer = customerService.updateCustomer(id, customer);
        CustomerDTO customerDTO = convertToDTO(updatedCustomer);
        return ResponseEntity.ok(customerResourceAssembler.toModel(customerDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable("id") @NotNull Long id) {
        customerService.deleteCustomer(id);
        return ResponseEntity.noContent().build();
    }

    private CustomerDTO convertToDTO(Customer customer) {
        return new CustomerDTO(customer.getId(), customer.getName(), customer.getEmail());
    }
}
