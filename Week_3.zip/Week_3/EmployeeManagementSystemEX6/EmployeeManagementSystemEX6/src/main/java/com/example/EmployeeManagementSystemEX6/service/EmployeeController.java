package com.example.EmployeeManagementSystemEX6.service;

import org.jboss.arquillian.extension.guice.testsuite.EmployeeModule;
import org.jboss.arquillian.extension.guice.testsuite.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.example.EmployeeManagementSystemEX6.controller.GetMapping;
import com.example.EmployeeManagementSystemEX6.controller.RequestParam;
import com.example.EmployeeManagementSystemEX6.controller.RestController;
import com.example.EmployeeManagementSystemEX6.entity.Employee;

@SuppressWarnings("unused")
@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/employees/by-department")
    public Page<EmployeeModule> getEmployeesByDepartment(@RequestParam final String department,
            final Pageable pageable) {
        return ((EmployeeController) employeeService).getEmployeesByDepartment(department, pageable);
    }

    @GetMapping("/employees/by-name")
    public Page<EmployeeModule> getEmployeesByNameContaining(@RequestParam final String namePart,
            final Pageable pageable) {
        return ((EmployeeController) employeeService).getEmployeesByNameContaining(namePart, pageable);
    }

    @GetMapping("/employees/by-salary")
    public Page<EmployeeModule> getEmployeesBySalaryGreaterThan(@RequestParam final Double salary,
            final Pageable pageable) {
        return ((EmployeeController) employeeService).getEmployeesBySalaryGreaterThan(salary, pageable);
    }

    @GetMapping("/employees/by-name-department")
    public Page<EmployeeModule> getEmployeesByNameAndDepartment(@RequestParam final String name,
            @RequestParam final String department, final Pageable pageable) {
        return ((EmployeeController) employeeService).getEmployeesByNameAndDepartment(name, department, pageable);
    }
}
