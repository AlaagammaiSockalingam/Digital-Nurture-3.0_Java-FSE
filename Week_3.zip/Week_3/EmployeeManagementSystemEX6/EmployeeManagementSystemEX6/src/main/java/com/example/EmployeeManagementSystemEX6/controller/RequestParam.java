package com.example.EmployeeManagementSystemEX6.controller;

public @interface RequestParam {

}
