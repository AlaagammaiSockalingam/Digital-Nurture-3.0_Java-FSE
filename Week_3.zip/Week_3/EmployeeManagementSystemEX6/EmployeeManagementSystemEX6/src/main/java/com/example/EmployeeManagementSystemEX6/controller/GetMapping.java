package com.example.EmployeeManagementSystemEX6.controller;

public @interface GetMapping {

    String value();

}
