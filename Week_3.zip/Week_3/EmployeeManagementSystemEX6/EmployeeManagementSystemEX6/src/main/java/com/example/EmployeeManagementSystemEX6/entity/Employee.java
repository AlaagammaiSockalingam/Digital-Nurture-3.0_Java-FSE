package com.example.EmployeeManagementSystemEX6.entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import org.springframework.data.annotation.Id;

import com.google.inject.name.Named;

@Entity
@NamedQueries({
        @NamedQuery(name = "Employee.findByDepartment", query = "SELECT e FROM Employee e WHERE e.department = :department"),
        @Named(name = "Employee.findHighSalaryEmployees", query = "SELECT e FROM Employee e WHERE e.salary > :salary", value = "")
})
@Data
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String department;
    private Double salary;
}
