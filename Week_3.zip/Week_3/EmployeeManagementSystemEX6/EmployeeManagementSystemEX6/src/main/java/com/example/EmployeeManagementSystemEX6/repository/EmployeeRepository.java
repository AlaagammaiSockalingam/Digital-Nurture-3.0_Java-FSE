package com.example.EmployeeManagementSystemEX6.repository;

import org.jboss.arquillian.extension.guice.testsuite.Employee;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Find employees by department with pagination
    Page<Employee> findByDepartment(String department, Pageable pageable);

    // Find employees by name containing a specific substring with pagination
    Page<Employee> findByNameContaining(String namePart, Pageable pageable);

    // Find employees with a salary greater than a specified amount with pagination
    Page<Employee> findBySalaryGreaterThan(Double salary, Pageable pageable);

    // Find employees by name and department with pagination
    Page<Employee> findByNameAndDepartment(String name, String department, Pageable pageable);
}
