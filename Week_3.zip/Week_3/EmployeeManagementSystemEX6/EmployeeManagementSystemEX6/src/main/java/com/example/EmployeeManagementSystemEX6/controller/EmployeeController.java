package com.example.EmployeeManagementSystemEX6.controller;

import org.jboss.arquillian.extension.guice.testsuite.Employee;
import org.jboss.arquillian.extension.guice.testsuite.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/employees/by-department")
    public Page<Employee> getEmployeesByDepartment(@RequestParam String department, Pageable pageable) {
        return ((EmployeeController) employeeService).getEmployeesByDepartment(department, pageable);
    }

    @GetMapping("/employees/by-name")
    public Page<Employee> getEmployeesByNameContaining(@RequestParam String namePart, Pageable pageable) {
        return ((EmployeeController) employeeService).getEmployeesByNameContaining(namePart, pageable);
    }

    @GetMapping("/employees/by-salary")
    public Page<Employee> getEmployeesBySalaryGreaterThan(@RequestParam Double salary, Pageable pageable) {
        return ((EmployeeController) employeeService).getEmployeesBySalaryGreaterThan(salary, pageable);
    }

    @GetMapping("/employees/by-name-department")
    public Page<Employee> getEmployeesByNameAndDepartment(@RequestParam String name, @RequestParam String department, Pageable pageable) {
        return ((EmployeeController) employeeService).getEmployeesByNameAndDepartment(name, department, pageable);
    }
}
