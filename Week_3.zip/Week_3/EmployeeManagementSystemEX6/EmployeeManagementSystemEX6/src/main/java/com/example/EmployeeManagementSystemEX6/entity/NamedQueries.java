package com.example.EmployeeManagementSystemEX6.entity;

public @interface NamedQueries {

}
