package com.example.EmployeeManagementSystemEX7.entity;

public @interface LastModifiedDate {

}
