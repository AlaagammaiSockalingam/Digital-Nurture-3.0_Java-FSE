package com.example.EmployeeManagementSystemEX1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystemEx1Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemEx1Application.class, args);
	}

}
