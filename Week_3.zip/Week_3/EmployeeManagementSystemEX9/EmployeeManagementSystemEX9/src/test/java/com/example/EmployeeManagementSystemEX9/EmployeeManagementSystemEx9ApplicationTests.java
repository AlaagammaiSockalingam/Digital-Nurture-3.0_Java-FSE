package com.example.EmployeeManagementSystemEX9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementSystemEx9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
