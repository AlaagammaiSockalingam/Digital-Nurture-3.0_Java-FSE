package com.example.EmployeeManagementSystemEX3.repository;

import com.example.EmployeeManagementSystemEX3.Model.Department;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
    // Derived query method to find a department by its name
    Department findByName(String name);
}
