package com.example.EmployeeManagementSystemEX3.entity;

import com.example.EmployeeManagementSystemEX3.Model.Department;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.*;

import java.util.Objects;

Identity

public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String position;
    private Double salary;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

    // Constructors, Getters, Setters, equals, and hashCode methods
}
