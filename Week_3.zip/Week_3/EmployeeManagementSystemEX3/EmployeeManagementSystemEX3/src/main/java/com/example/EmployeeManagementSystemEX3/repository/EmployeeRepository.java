package com.example.EmployeeManagementSystemEX3.repository;

import com.example.EmployeeManagementSystemEX3.Model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // Derived query method to find employees by their name
    List<Employee> findByName(String name);

    // Derived query method to find an employee by their email
    Employee findByEmail(String email);
}
