package com.example.EmployeeManagementSystemEX3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystemEx3Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemEx3Application.class, args);
	}

}
