package com.example.EmployeeManagementSystemEX3;

import com.example.EmployeeManagementSystemEX3.Model.Department;
import com.example.EmployeeManagementSystemEX3.Model.Employee;
import com.example.EmployeeManagementSystemEX3.repository.DepartmentRepository;
import com.example.EmployeeManagementSystemEX3.repository.EmployeeRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {

    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;

    public DataLoader(EmployeeRepository employeeRepository, DepartmentRepository departmentRepository) {
        this.employeeRepository = employeeRepository;
        this.departmentRepository = departmentRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        // Create and save a department
        Department department = new Department();
        department.setName("Engineering");
        department = departmentRepository.save(department);

        // Create and save employees
        Employee employee1 = new Employee();
        employee1.setFirstName("John Doe");
        employee1.setEmail("john.doe@example.com");

        Employee employee2 = new Employee();
        employee2.setFirstName("Jane Smith");
        employee2.setEmail("jane.smith@example.com");

        employeeRepository.save(employee1);
        employeeRepository.save(employee2);

        // Test derived query methods
        System.out.println("Employees named John Doe: " + employeeRepository.findByName("John Doe"));
        System.out.println(
                "Employee with email john.doe@example.com: " + employeeRepository.findByEmail("john.doe@example.com"));
        System.out.println("Department named Engineering: " + departmentRepository.findByName("Engineering"));
    }
}
