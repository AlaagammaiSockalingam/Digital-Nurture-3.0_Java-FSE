package com.example.EmployeeManagementSystemEX3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementSystemEx3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
