package com.example.EmployeeManagementSystemEX8.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.EmployeeManagementSystemEX8.dto.EmployeeDTO;
import com.example.EmployeeManagementSystemEX8.entity.Employee;
import com.example.EmployeeManagementSystemEX8.projection.EmployeeProjection;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // Interface-based projection example
    @Query("SELECT e.name AS name, e.salary AS salary FROM Employee e WHERE e.id = :id")
    EmployeeProjection findEmployeeProjectionById(@Param("id") Long id);

    // Class-based projection example
    @Query("SELECT new com.example.EmployeeDTO(e.name, e.salary) FROM Employee e WHERE e.id = :id")
    EmployeeDTO findEmployeeDTOById(@Param("id") Long id);
}

@Query("SELECT new com.example.dto.EmployeeDTO(e.name, e.salary) FROM Employee e WHERE e.id = :id")
EmployeeDTO findEmployeeDTOById(@Param("id") Long id);
