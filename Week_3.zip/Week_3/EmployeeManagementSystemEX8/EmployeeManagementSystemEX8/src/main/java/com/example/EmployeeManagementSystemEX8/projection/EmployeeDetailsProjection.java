package com.example.EmployeeManagementSystemEX8.projection;

import org.springframework.beans.factory.annotation.Value;

public interface EmployeeDetailsProjection {
    @Value("#{target.name} - #{target.salary}")
    String getFormattedDetails();
}
