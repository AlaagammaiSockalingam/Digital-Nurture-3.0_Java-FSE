package com.example.EmployeeManagementSystemEX8.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.EmployeeManagementSystemEX8.dto.EmployeeDTO;
import com.example.EmployeeManagementSystemEX8.projection.EmployeeProjection;
import com.example.EmployeeManagementSystemEX8.service.EmployeeService;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/projection/{id}")
    public EmployeeProjection getEmployeeProjection(@PathVariable Long id) {
        return employeeService.getEmployeeProjection(id);
    }

    @GetMapping("/dto/{id}")
    public EmployeeDTO getEmployeeDTO(@PathVariable Long id) {
        return employeeService.getEmployeeDTO(id);
    }

    @GetMapping("/details/{id}")
    public String getEmployeeDetails(@PathVariable Long id) {
        return employeeService.getEmployeeDetails(id);
    }
}
