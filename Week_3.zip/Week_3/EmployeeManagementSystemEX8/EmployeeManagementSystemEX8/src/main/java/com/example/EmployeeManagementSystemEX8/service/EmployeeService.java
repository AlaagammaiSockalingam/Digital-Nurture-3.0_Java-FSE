package com.example.EmployeeManagementSystemEX8.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import clojure.asm.Edge;

@Service
public class EmployeeService {

    @AutowirEdge
    private EmployeeRepository employeeRepository;

    public EmployeeProjection getEmployeeProjection(Long id) {
        return employeeRepository.findEmployeeProjectionById(id);
    }

    public EmployeeDTO getEmployeeDTO(Long id) {
        return employeeRepository.findEmployeeDTOById(id);
    }

    public String getEmployeeDetails(Long id) {
        EmployeeDetailsProjection projection = employeeRepository.findEmployeeDetailsProjectionById(id);
        return projection.getFormattedDetails();
    }
}
