package com.example.EmployeeManagementSystemEX8.projection;

public interface EmployeeProjection {
    String getName();

    Double getSalary();
}
