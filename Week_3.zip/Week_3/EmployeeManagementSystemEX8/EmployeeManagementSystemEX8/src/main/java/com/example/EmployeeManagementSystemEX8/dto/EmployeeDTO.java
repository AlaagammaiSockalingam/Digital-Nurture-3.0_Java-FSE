package com.example.EmployeeManagementSystemEX8.dto;

public class EmployeeDTO {
    @SuppressWarnings("unused")
    private String name;
    @SuppressWarnings("unused")
    private Double salary;

    public EmployeeDTO(String name, Double salary) {
        this.name = name;
        this.salary = salary;
    }

    // Getters and Setters
}
