package com.example.EmployeeManagementSystemEX8.entity;

import java.util.List;

import javax.persistence.*;

import org.springframework.data.annotation.Id;

@Entity
public class Department {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @OneToMany(mappedBy = "department")
    private List<Employee> employees;

    // Constructors, Getters, Setters, equals, and hashCode methods
}
