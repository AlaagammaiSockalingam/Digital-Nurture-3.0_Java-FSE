package com.example.EmployeeManagementSystemEX4.repository;

import com.example.EmployeeManagementSystemEX4.Model.Department;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
}
