package com.example.EmployeeManagementSystemEX2.repository;

import com.example.EmployeeManagementSystemEX2.Model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
}
