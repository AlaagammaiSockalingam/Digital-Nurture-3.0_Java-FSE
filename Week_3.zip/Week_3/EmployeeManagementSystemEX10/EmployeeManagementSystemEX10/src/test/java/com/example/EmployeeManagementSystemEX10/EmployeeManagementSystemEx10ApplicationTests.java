package com.example.EmployeeManagementSystemEX10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementSystemEx10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
