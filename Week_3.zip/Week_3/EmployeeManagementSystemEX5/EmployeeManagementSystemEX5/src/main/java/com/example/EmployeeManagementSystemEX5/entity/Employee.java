package com.example.EmployeeManagementSystemEX5.entity;

import jakarta.persistence.*;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.*;
import lombok.*;
import lombok.Data;

@Entity
@NamedQueries({
        @NamedQuery(name = "Employee.findByDepartment", query = "SELECT e FROM Employee e WHERE e.department = :department"),
        @NamedQuery(name = "Employee.findHighSalaryEmployees", query = "SELECT e FROM Employee e WHERE e.salary > :salary")
})
@Data
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String department;
    private Double salary;
}
