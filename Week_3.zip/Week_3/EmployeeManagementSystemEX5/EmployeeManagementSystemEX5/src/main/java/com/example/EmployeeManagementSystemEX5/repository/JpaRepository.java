package com.example.EmployeeManagementSystemEX5.repository;

public interface JpaRepository<T1, T2> {

}
