package com.example.EmployeeManagementSystemEX5.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.EmployeeManagementSystemEX5.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Custom JPQL query to find employees by department
    @Query("SELECT e FROM Employee e WHERE e.department = :department")
    List<Employee> findEmployeesByDepartment(@Param("department") String department);

    // Custom native SQL query to find employees by salary range
    @Query(value = "SELECT * FROM employee WHERE salary BETWEEN :minSalary AND :maxSalary", nativeQuery = true)
    List<Employee> findEmployeesBySalaryRange(@Param("minSalary") Double minSalary,
            @Param("maxSalary") Double maxSalary);

    // Custom JPQL query to find employees with a salary higher than a certain
    // amount and belonging to a department
    @Query("SELECT e FROM Employee e WHERE e.salary > :salary AND e.department = :department")
    List<Employee> findHighSalaryEmployeesInDepartment(@Param("salary") Double salary,
            @Param("department") String department);
}
