CREATE OR REPLACE PACKAGE AccountOperations AS
  -- Procedure to open a new account
  PROCEDURE OpenAccount(
    p_AccountID IN Accounts.AccountID%TYPE,
    p_CustomerID IN Accounts.CustomerID%TYPE,
    p_Balance IN Accounts.Balance%TYPE
  );

  -- Procedure to close an account
  PROCEDURE CloseAccount(
    p_AccountID IN Accounts.AccountID%TYPE
  );

  -- Function to get the total balance of a customer across all accounts
  FUNCTION GetTotalBalance(
    p_CustomerID IN Accounts.CustomerID%TYPE
  ) RETURN NUMBER;
END AccountOperations;

CREATE OR REPLACE PACKAGE BODY AccountOperations AS
  -- Procedure to open a new account
  PROCEDURE OpenAccount(
    p_AccountID IN Accounts.AccountID%TYPE,
    p_CustomerID IN Accounts.CustomerID%TYPE,
    p_Balance IN Accounts.Balance%TYPE
  ) AS
  BEGIN
    INSERT INTO Accounts (AccountID, CustomerID, Balance)
    VALUES (p_AccountID, p_CustomerID, p_Balance);
    COMMIT;
  END OpenAccount;

  -- Procedure to close an account
  PROCEDURE CloseAccount(
    p_AccountID IN Accounts.AccountID%TYPE
  ) AS
  BEGIN
    DELETE FROM Accounts
    WHERE AccountID = p_AccountID;
    COMMIT;
  END CloseAccount;

  -- Function to get the total balance of a customer across all accounts
  FUNCTION GetTotalBalance(
    p_CustomerID IN Accounts.CustomerID%TYPE
  ) RETURN NUMBER AS
    v_TotalBalance NUMBER;
  BEGIN
    SELECT SUM(Balance) INTO v_TotalBalance
    FROM Accounts
    WHERE CustomerID = p_CustomerID;
    RETURN v_TotalBalance;
  END GetTotalBalance;
END AccountOperations;