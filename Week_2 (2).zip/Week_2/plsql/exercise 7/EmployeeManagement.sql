CREATE OR REPLACE PACKAGE EmployeeManagement AS
  -- Procedure to hire a new employee
  PROCEDURE HireEmployee(
    p_EmployeeID IN Employees.EmployeeID%TYPE,
    p_EmployeeName IN Employees.EmployeeName%TYPE,
    p_Salary IN Employees.Salary%TYPE
  );

  -- Procedure to update employee details
  PROCEDURE UpdateEmployee(
    p_EmployeeID IN Employees.EmployeeID%TYPE,
    p_EmployeeName IN Employees.EmployeeName%TYPE,
    p_Salary IN Employees.Salary%TYPE
  );

  -- Function to calculate annual salary
  FUNCTION CalculateAnnualSalary(
    p_Salary IN Employees.Salary%TYPE
  ) RETURN NUMBER;
END EmployeeManagement;

CREATE OR REPLACE PACKAGE BODY EmployeeManagement AS
  -- Procedure to hire a new employee
  PROCEDURE HireEmployee(
    p_EmployeeID IN Employees.EmployeeID%TYPE,
    p_EmployeeName IN Employees.EmployeeName%TYPE,
    p_Salary IN Employees.Salary%TYPE
  ) AS
  BEGIN
    INSERT INTO Employees (EmployeeID, EmployeeName, Salary)
    VALUES (p_EmployeeID, p_EmployeeName, p_Salary);
    COMMIT;
  END HireEmployee;

  -- Procedure to update employee details
  PROCEDURE UpdateEmployee(
    p_EmployeeID IN Employees.EmployeeID%TYPE,
    p_EmployeeName IN Employees.EmployeeName%TYPE,
    p_Salary IN Employees.Salary%TYPE
  ) AS
  BEGIN
    UPDATE Employees
    SET EmployeeName = p_EmployeeName, Salary = p_Salary
    WHERE EmployeeID = p_EmployeeID;
    COMMIT;
  END UpdateEmployee;

  -- Function to calculate annual salary
  FUNCTION CalculateAnnualSalary(
    p_Salary IN Employees.Salary%TYPE
  ) RETURN NUMBER AS
  BEGIN
    RETURN p_Salary * 12;
  END CalculateAnnualSalary;
END EmployeeManagement;