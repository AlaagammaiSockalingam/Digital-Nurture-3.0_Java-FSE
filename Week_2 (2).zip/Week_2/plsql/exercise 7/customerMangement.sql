CREATE OR REPLACE PACKAGE CustomerManagement AS
  -- Procedure to add a new customer
  PROCEDURE AddCustomer(
    p_CustomerID IN Customers.CustomerID%TYPE,
    p_CustomerName IN Customers.CustomerName%TYPE
  );

  -- Procedure to update customer details
  PROCEDURE UpdateCustomer(
    p_CustomerID IN Customers.CustomerID%TYPE,
    p_CustomerName IN Customers.CustomerName%TYPE
  );

  -- Function to get customer balance
  FUNCTION GetCustomerBalance(
    p_CustomerID IN Customers.CustomerID%TYPE
  ) RETURN NUMBER;
END CustomerManagement;

CREATE OR REPLACE PACKAGE BODY CustomerManagement AS
  -- Procedure to add a new customer
  PROCEDURE AddCustomer(
    p_CustomerID IN Customers.CustomerID%TYPE,
    p_CustomerName IN Customers.CustomerName%TYPE
  ) AS
  BEGIN
    INSERT INTO Customers (CustomerID, CustomerName)
    VALUES (p_CustomerID, p_CustomerName);
    COMMIT;
  END AddCustomer;

  -- Procedure to update customer details
  PROCEDURE UpdateCustomer(
    p_CustomerID IN Customers.CustomerID%TYPE,
    p_CustomerName IN Customers.CustomerName%TYPE
  ) AS
  BEGIN
    UPDATE Customers
    SET CustomerName = p_CustomerName
    WHERE CustomerID = p_CustomerID;
    COMMIT;
  END UpdateCustomer;

  -- Function to get customer balance
  FUNCTION GetCustomerBalance(
    p_CustomerID IN Customers.CustomerID%TYPE
  ) RETURN NUMBER AS
    v_Balance NUMBER;
  BEGIN
    SELECT SUM(LoanAmount) INTO v_Balance
    FROM Loans
    WHERE CustomerID = p_CustomerID;
    RETURN v_Balance;
  END GetCustomerBalance;
END CustomerManagement;
BEGIN
  CustomerManagement.AddCustomer(5, 'Jane Doe');
  CustomerManagement.UpdateCustomer(1, 'John Doe Updated');
  DBMS_OUTPUT.PUT_LINE('Customer 1 balance: ' || CustomerManagement.GetCustomerBalance(1));
END;