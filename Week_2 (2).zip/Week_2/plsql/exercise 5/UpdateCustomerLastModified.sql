CREATE OR REPLACE TRIGGER UpdateCustomerLastModified
BEFORE UPDATE ON CUSTOMERS
FOR EACH ROW
BEGIN
    :NEW.LastModified := SYSDATE;
END;
/
-- Update John Doe's record (for example, change the name)
UPDATE CUSTOMERS
SET NAME = 'John Smith'
WHERE CUSTOMER_ID = 1;

-- Check the updated record
SELECT * FROM CUSTOMERS WHERE CUSTOMER_ID = 1;
