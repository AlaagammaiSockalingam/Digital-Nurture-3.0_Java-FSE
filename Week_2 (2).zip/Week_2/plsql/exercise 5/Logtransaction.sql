CREATE TABLE Transactions (
  TransactionID INT PRIMARY KEY,
  AccountNumber INT,
  TransactionDate DATE,
  Amount DECIMAL(10, 2),
  TransactionType VARCHAR(10)
);
CREATE TABLE AuditLog (
  AuditLogID INT PRIMARY KEY,
  TransactionID INT,
  TransactionDate DATE,
  AuditMessage VARCHAR(255),
  CreatedDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE OR REPLACE TRIGGER LogTransaction
AFTER INSERT ON Transactions
FOR EACH ROW
BEGIN
  INSERT INTO AuditLog (TransactionID, TransactionDate, AuditMessage)
  VALUES (:NEW.TransactionID, :NEW.TransactionDate, 'Transaction inserted successfully');
END;
/
-- Create a sequence for the TRANSACTIONID column
CREATE SEQUENCE transaction_id_seq;
SELECT * FROM AuditLog;

-- Insert a record into the Transactions table
INSERT INTO Transactions (TransactionID, AccountNumber, TransactionDate, Amount, TransactionType)
VALUES (transaction_id_seq.NEXTVAL, 12345, '2022-01-01', 100.00, 'Deposit');

-- Commit the transaction to ensure the trigger is executed
COMMIT;