CREATE TABLE Transactions (
  TransactionID NUMBER PRIMARY KEY,
  AccountID NUMBER(38,0),
  TransactionDate DATE,
  Amount NUMBER(15,2),
  TransactionType VARCHAR2(10),
  CONSTRAINT fk_AccountID FOREIGN KEY (AccountID) REFERENCES Accounts(AccountID)
);
CREATE SEQUENCE transaction_id_seq;

-- Insert data into the Transactions table
INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (transaction_id_seq.NEXTVAL, 1, '2022-01-01', 500.00, 'Deposit');
CREATE OR REPLACE TRIGGER CheckTransactionRules
BEFORE INSERT ON Transactions
FOR EACH ROW
DECLARE
  v_balance NUMBER(15,2);
BEGIN
  -- Get the current balance for the account
  SELECT Balance INTO v_balance
  FROM Accounts
  WHERE AccountID = :NEW.AccountID;

  -- Check if the transaction is a withdrawal
  IF :NEW.TransactionType = 'Withdrawal' THEN
    -- Check if the withdrawal amount exceeds the balance
    IF :NEW.Amount > v_balance THEN
      RAISE_APPLICATION_ERROR(-20001, 'Withdrawal amount exceeds balance');
      
    END IF;
  ELSIF :NEW.TransactionType = 'Deposit' THEN
    -- Check if the deposit amount is positive
    IF :NEW.Amount <= 0 THEN
      RAISE_APPLICATION_ERROR(-20002, 'Deposit amount must be positive');
    END IF;
  END IF;
END CheckTransactionRules;
/
-- Try to insert a withdrawal that exceeds the balance
INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (transaction_id_seq.NEXTVAL, 1, '2022-01-02', 1500.00, 'Withdrawal');

-- This should raise an application error: "Withdrawal amount exceeds balance"

-- Try to insert a deposit with a negative amount
INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (transaction_id_seq.NEXTVAL, 1, '2022-01-03', -100.00, 'Deposit');

-- This should raise an application error: "Deposit amount must be positive"

-- Try to insert a valid withdrawal
INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (transaction_id_seq.NEXTVAL, 1, '2022-01-04', 200.00, 'Withdrawal');

-- This should succeed

-- Try to insert a valid deposit
INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (transaction_id_seq.NEXTVAL, 1, '2022-01-05', 300.00, 'Deposit');

-- This should succeed