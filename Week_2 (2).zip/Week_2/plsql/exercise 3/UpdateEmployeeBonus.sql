CREATE TABLE EMPLOYEES (
    EMPLOYEE_ID NUMBER,
    EMPLOYEE_NAME VARCHAR2(100),
    DEPARTMENT VARCHAR2(100),
    SALARY NUMBER(15,2)
);
INSERT INTO EMPLOYEES (EMPLOYEE_ID, EMPLOYEE_NAME, DEPARTMENT, SALARY)
VALUES (1, 'John Doe', 'HR', 50000.00);

INSERT INTO EMPLOYEES (EMPLOYEE_ID, EMPLOYEE_NAME, DEPARTMENT, SALARY)
VALUES (2, 'Jane Smith', 'IT', 60000.00);

INSERT INTO EMPLOYEES (EMPLOYEE_ID, EMPLOYEE_NAME, DEPARTMENT, SALARY)
VALUES (3, 'Michael Johnson', 'HR', 55000.00);

INSERT INTO EMPLOYEES (EMPLOYEE_ID, EMPLOYEE_NAME, DEPARTMENT, SALARY)
VALUES (4, 'Emily Davis', 'IT', 62000.00);
CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus (
    p_department    IN  VARCHAR2,
    p_bonus_percent IN  NUMBER
)
IS
    v_err_msg   VARCHAR2(200);
BEGIN
    -- Step 1: Begin transaction
    SAVEPOINT start_tran;

    -- Step 2: Update salary for employees in the specified department
    UPDATE EMPLOYEES
    SET SALARY = SALARY * (1 + p_bonus_percent / 100)
    WHERE DEPARTMENT = p_department;

    -- Step 3: Commit transaction
    COMMIT;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        v_err_msg := 'No employees found in department ' || p_department;
        INSERT INTO ERROR_LOG (ERROR_MESSAGE, ERROR_TIMESTAMP)
        VALUES (v_err_msg, SYSTIMESTAMP);
        RAISE_APPLICATION_ERROR(-20001, v_err_msg);
        
    WHEN OTHERS THEN
        v_err_msg := 'Error updating employee bonus: ' || SQLERRM;
        ROLLBACK TO SAVEPOINT start_tran;
        INSERT INTO ERROR_LOG (ERROR_MESSAGE, ERROR_TIMESTAMP)
        VALUES (v_err_msg, SYSTIMESTAMP);
        RAISE;
END UpdateEmployeeBonus;
/
-- Test with a bonus percentage increase of 5% for employees in the 'HR' department
BEGIN
    UpdateEmployeeBonus('HR', 5);
END;
/

-- Test with a bonus percentage increase of 3% for employees in the 'IT' department
BEGIN
    UpdateEmployeeBonus('IT', 3);
END;
/

-- Check updated salaries in the EMPLOYEES table
SELECT * FROM EMPLOYEES;

-- Check the ERROR_LOG table for any errors logged during the process
SELECT * FROM ERROR_LOG;




