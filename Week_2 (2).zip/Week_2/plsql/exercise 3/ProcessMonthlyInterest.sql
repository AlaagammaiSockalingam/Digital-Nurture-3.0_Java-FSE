CREATE TABLE SAVINGS_ACCOUNTS (
    ACCOUNT_ID NUMBER,
    ACCOUNT_NAME VARCHAR2(100),
    BALANCE NUMBER(15,2)
);
INSERT INTO SAVINGS_ACCOUNTS (ACCOUNT_ID, ACCOUNT_NAME, BALANCE)
VALUES (1, 'Savings Account A', 1000.00);

INSERT INTO SAVINGS_ACCOUNTS (ACCOUNT_ID, ACCOUNT_NAME, BALANCE)
VALUES (2, 'Savings Account B', 500.00);

CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest
IS
    v_err_msg   VARCHAR2(200);
BEGIN
    -- Step 1: Begin transaction
    SAVEPOINT start_tran;

    -- Step 2: Calculate and update interest for all savings accounts
    UPDATE SAVINGS_ACCOUNTS
    SET BALANCE = BALANCE * 1.01; -- Applying 1% interest rate

    -- Step 3: Commit transaction
    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        v_err_msg := 'Error processing monthly interest: ' || SQLERRM;
        ROLLBACK TO SAVEPOINT start_tran;
        INSERT INTO ERROR_LOG (ERROR_MESSAGE, ERROR_TIMESTAMP)
        VALUES (v_err_msg, SYSTIMESTAMP);
        RAISE;
END ProcessMonthlyInterest;
/
-- Execute the procedure to process monthly interest
BEGIN
    ProcessMonthlyInterest;
END;
/

-- Check updated balances in the SAVINGS_ACCOUNTS table
SELECT * FROM SAVINGS_ACCOUNTS;

-- Check the ERROR_LOG table for any errors logged during the process
SELECT * FROM ERROR_LOG;

