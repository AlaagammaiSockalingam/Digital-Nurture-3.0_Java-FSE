CREATE OR REPLACE PROCEDURE TransferFunds (
    p_from_account_id   IN  NUMBER,
    p_to_account_id     IN  NUMBER,
    p_amount            IN  NUMBER
)
IS
    v_from_balance  NUMBER(15,2);
    v_to_balance    NUMBER(15,2);
    v_err_msg       VARCHAR2(200);
BEGIN
    -- Step 1: Begin transaction
    SAVEPOINT start_tran;

    -- Step 2: Retrieve current balances
    SELECT BALANCE INTO v_from_balance
    FROM ACCOUNTS
    WHERE ACCOUNTID = p_from_account_id;

    SELECT BALANCE INTO v_to_balance
    FROM ACCOUNTS
    WHERE ACCOUNTID = p_to_account_id;

    -- Step 3: Check if from_account has sufficient balance
    IF v_from_balance < p_amount THEN
        v_err_msg := 'Insufficient funds in the source account.';
        RAISE_APPLICATION_ERROR(-20001, v_err_msg);
    END IF;

    -- Step 4: Perform the transfer
    UPDATE ACCOUNTS
    SET BALANCE = BALANCE - p_amount
    WHERE ACCOUNTID = p_from_account_id;

    UPDATE ACCOUNTS
    SET BALANCE = BALANCE + p_amount
    WHERE ACCOUNTID = p_to_account_id;

    -- Step 5: Commit transaction
    COMMIT;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        v_err_msg := 'One or both accounts not found.';
        INSERT INTO ERROR_LOG (ERROR_MESSAGE, ERROR_TIMESTAMP)
        VALUES (v_err_msg, SYSTIMESTAMP);
        ROLLBACK TO SAVEPOINT start_tran;
        RAISE_APPLICATION_ERROR(-20002, v_err_msg);

    WHEN OTHERS THEN
        v_err_msg := 'Error during fund transfer: ' || SQLERRM;
        ROLLBACK TO SAVEPOINT start_tran;
        INSERT INTO ERROR_LOG (ERROR_MESSAGE, ERROR_TIMESTAMP)
        VALUES (v_err_msg, SYSTIMESTAMP);
        RAISE;
END TransferFunds;
/
-- Test transferring 300 units from Account ID 1 to Account ID 2
BEGIN
    TransferFunds(1, 2, 300);
END;
/

-- Test transferring 800 units from Account ID 2 to Account ID 1 (should raise an error)
BEGIN
    TransferFunds(2, 1, 800);
END;
/

-- Check updated balances in the ACCOUNTS table
SELECT * FROM ACCOUNTS;

-- Check the ERROR_LOG table for any errors logged during the process
SELECT * FROM ERROR_LOG;
