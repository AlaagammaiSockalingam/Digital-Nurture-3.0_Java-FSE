CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment (
    p_loan_id             IN NUMBER,
    p_loan_amount         IN NUMBER,
    p_interest_rate       IN NUMBER,
    p_loan_duration_years IN NUMBER
)
RETURN NUMBER
IS
    v_monthly_interest   NUMBER;
    v_total_months       NUMBER;
    v_monthly_installment NUMBER;
BEGIN
    -- Calculate monthly interest rate
    v_monthly_interest := p_interest_rate / 100 / 12;

    -- Calculate total number of months
    v_total_months := p_loan_duration_years * 12;

    -- Calculate monthly installment amount using formula
    v_monthly_installment := (p_loan_amount * v_monthly_interest) /
                             (1 - (1 + v_monthly_interest)**(-v_total_months));

    RETURN v_monthly_installment;
END CalculateMonthlyInstallment;
/
-- Test with Loan ID 1, Loan Amount $10,000, 5% interest rate, and 3 years duration
SELECT CalculateMonthlyInstallment(1, 10000.00, 5.0, 3) AS MONTHLY_INSTALLMENT
FROM DUAL;

-- Test with Loan ID 2, Loan Amount $20,000, 4.5% interest rate, and 5 years duration
SELECT CalculateMonthlyInstallment(2, 20000.00, 4.5, 5) AS MONTHLY_INSTALLMENT
FROM DUAL;

-- Test with Loan ID 3, Loan Amount $15,000, 6.25% interest rate, and 2 years duration
SELECT CalculateMonthlyInstallment(3, 15000.00, 6.25, 2) AS MONTHLY_INSTALLMENT
FROM DUAL;
