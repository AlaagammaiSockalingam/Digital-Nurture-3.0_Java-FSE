CREATE OR REPLACE FUNCTION CalculateAge (
    p_date_of_birth IN DATE
)
RETURN NUMBER
IS
    v_age NUMBER;
BEGIN
    -- Calculate age using current date and date of birth
    SELECT FLOOR(MONTHS_BETWEEN(SYSDATE, p_date_of_birth) / 12) INTO v_age
    FROM DUAL;

    RETURN v_age;
END CalculateAge;
/
SELECT CalculateAge(DATE_OF_BIRTH)
FROM CUSTOMERS
WHERE NAME = 'John Doe';
SELECT CalculateAge(DATE_OF_BIRTH)
FROM CUSTOMERS
WHERE NAME = 'Jane Smith';
SELECT CalculateAge(DATE_OF_BIRTH)
FROM CUSTOMERS
WHERE NAME = 'Michael Johnson';