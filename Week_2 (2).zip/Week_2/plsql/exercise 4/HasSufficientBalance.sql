CREATE OR REPLACE FUNCTION HasSufficientBalance (
    p_account_id IN NUMBER,
    p_amount IN NUMBER
)
RETURN BOOLEAN
IS
    v_balance NUMBER;
    v_has_sufficient BOOLEAN := FALSE;
BEGIN
    -- Retrieve the balance of the account
    SELECT BALANCE INTO v_balance
    FROM ACCOUNTS
    WHERE ACCOUNTID = p_account_id;

    -- Check if the account has at least the specified amount
    IF v_balance >= p_amount THEN
        v_has_sufficient := TRUE;
    END IF;

    RETURN v_has_sufficient;
END HasSufficientBalance;
/
-- Test with Account ID 1 and amount $2000
SELECT HasSufficientBalance(1, 2000) AS SUFFICIENT_BALANCE FROM DUAL;

-- Test with Account ID 2 and amount $15000
SELECT HasSufficientBalance(2, 15000) AS SUFFICIENT_BALANCE FROM DUAL;

-- Test with Account ID 3 and amount $10000
SELECT HasSufficientBalance(3, 10000) AS SUFFICIENT_BALANCE FROM DUAL;
