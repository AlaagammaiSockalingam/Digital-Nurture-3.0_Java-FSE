DECLARE
20  CURSOR ApplyAnnualFee IS
21    SELECT AccountID, Balance
22    FROM Accounts;
23
24  v_AccountID NUMBER;
25  v_Balance NUMBER(15,2);
26  v_AnnualFee NUMBER(15,2) := 25.00; -- annual maintenance fee
27
28BEGIN
29  OPEN ApplyAnnualFee;
30  LOOP
31    FETCH ApplyAnnualFee INTO v_AccountID, v_Balance;
32    EXIT WHEN ApplyAnnualFee%NOTFOUND;
33
34    -- deduct the annual maintenance fee from the balance
35    v_Balance := v_Balance - v_AnnualFee;
36
37    -- update the balance in the Accounts table
38    UPDATE Accounts
39    SET Balance = v_Balance
40    WHERE AccountID = v_AccountID;
41
42    DBMS_OUTPUT.PUT_LINE('Annual maintenance fee deducted from Account ' || v_AccountID);
43  END LOOP;
44  CLOSE ApplyAnnualFee;
45END;
46/
