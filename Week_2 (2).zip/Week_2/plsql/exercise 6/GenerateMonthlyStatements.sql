DECLARE
  CURSOR GenerateMonthlyStatements IS
    SELECT c.CustomerName, a.AccountID, t.TransactionDate, t.Amount, t.TransactionType
    FROM Customers c
    JOIN Accounts a ON c.CustomerID = a.CustomerID
    JOIN Transactions t ON a.AccountID = t.AccountID
    WHERE TRUNC(t.TransactionDate, 'MM') = TRUNC(SYSDATE, 'MM');

  v_CustomerName VARCHAR2(100 BYTE);
  v_AccountID NUMBER;
  v_TransactionDate DATE;
  v_Amount NUMBER(15,2);
  v_TransactionType VARCHAR2(10 BYTE);
BEGIN
  OPEN GenerateMonthlyStatements;
  LOOP
    FETCH GenerateMonthlyStatements INTO v_CustomerName, v_AccountID, v_TransactionDate, v_Amount, v_TransactionType;
    EXIT WHEN GenerateMonthlyStatements%NOTFOUND;

    DBMS_OUTPUT.PUT_LINE('Statement for ' || v_CustomerName || ' - Account ' || v_AccountID);
    DBMS_OUTPUT.PUT_LINE('Transaction Date: ' || v_TransactionDate);
    DBMS_OUTPUT.PUT_LINE('Amount: ' || v_Amount);
    DBMS_OUTPUT.PUT_LINE('Transaction Type: ' || v_TransactionType);
    DBMS_OUTPUT.PUT_LINE('-------------------------');
  END LOOP;
  CLOSE GenerateMonthlyStatements;
END;
/