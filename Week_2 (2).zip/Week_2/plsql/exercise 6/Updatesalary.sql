CREATE OR REPLACE PROCEDURE UpdateSalary (
    p_employee_id   IN  NUMBER,
    p_percent_increase IN  NUMBER
)
IS
    v_current_salary  NUMBER(15,2);
    v_new_salary      NUMBER(15,2);
    v_err_msg         VARCHAR2(200);
BEGIN
    -- Step 1: Begin transaction
    SAVEPOINT start_tran;

    -- Step 2: Retrieve current salary
    SELECT SALARY INTO v_current_salary
    FROM EMPLOYEE
    WHERE EMPLOYEE_ID = p_employee_id;

    -- Step 3: Check if employee ID exists
    IF SQL%NOTFOUND THEN
        v_err_msg := 'Employee with ID ' || p_employee_id || ' does not exist.';
        INSERT INTO ERROR_LOG (ERROR_MESSAGE, ERROR_TIMESTAMP)
        VALUES (v_err_msg, SYSTIMESTAMP);
        RAISE_APPLICATION_ERROR(-20001, v_err_msg);
    END IF;

    -- Step 4: Calculate new salary
    v_new_salary := v_current_salary * (1 + p_percent_increase / 100);

    -- Step 5: Update the salary
    UPDATE EMPLOYEE
    SET SALARY = v_new_salary
    WHERE EMPLOYEE_ID = p_employee_id;

    -- Step 6: Commit transaction
    COMMIT;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        v_err_msg := 'Employee with ID ' || p_employee_id || ' does not exist.';
        INSERT INTO ERROR_LOG (ERROR_MESSAGE, ERROR_TIMESTAMP)
        VALUES (v_err_msg, SYSTIMESTAMP);
        RAISE_APPLICATION_ERROR(-20002, v_err_msg);
        
    WHEN OTHERS THEN
        v_err_msg := 'Error updating salary: ' || SQLERRM;
        ROLLBACK TO SAVEPOINT start_tran;
        INSERT INTO ERROR_LOG (ERROR_MESSAGE, ERROR_TIMESTAMP)
        VALUES (v_err_msg, SYSTIMESTAMP);
        RAISE;
END UpdateSalary;
/
-- Test with existing employee ID (increase salary by 10% for Employee ID 1)
BEGIN
    UpdateSalary(1, 10);
END;
/

-- Test with non-existing employee ID (Employee ID 100 does not exist)
BEGIN
    UpdateSalary(100, 5);
END;
/

-- Check updated salaries and error log
SELECT * FROM EMPLOYEE;
SELECT * FROM ERROR_LOG;
