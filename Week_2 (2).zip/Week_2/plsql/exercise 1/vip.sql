SET SERVEROUTPUT ON
DBMS_OUTPUT.ENABLE(NULL);
DECLARE
  CURSOR cur_customers IS
    SELECT customer_id, name, balance, is_vip
    FROM customers1;

  rec_customer cur_customers%ROWTYPE;
BEGIN
  OPEN cur_customers;
  LOOP
    FETCH cur_customers INTO rec_customer;
    EXIT WHEN cur_customers%NOTFOUND;

    IF rec_customer.balance > 10000 THEN
      UPDATE customers1
      SET is_vip = 'Y'
      WHERE customer_id = rec_customer.customer_id;

      DBMS_OUTPUT.PUT_LINE('Customer ' || rec_customer.name || ' (ID: ' || rec_customer.customer_id || ') has been promoted to VIP status with a balance of ' || rec_customer.balance);
    END IF;
  END LOOP;
  CLOSE cur_customers;
END;


