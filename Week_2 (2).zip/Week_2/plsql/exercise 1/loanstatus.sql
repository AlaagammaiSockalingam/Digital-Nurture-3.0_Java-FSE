-- Enable server output
SET SERVEROUTPUT ON
DBMS_OUTPUT.ENABLE(NULL);
-- Create a PL/SQL block
BEGIN
  DECLARE
    CURSOR loan_cursor IS
      SELECT loan_id, customer_id, loan_amount, due_date, loan_status
      FROM loans1
      WHERE due_date BETWEEN SYSTIMESTAMP AND SYSTIMESTAMP + 30
      AND loan_status = 'OUTSTANDING';

    loan_rec loan_cursor%ROWTYPE;
  BEGIN
    OPEN loan_cursor;
    LOOP
      FETCH loan_cursor INTO loan_rec;
      EXIT WHEN loan_cursor%NOTFOUND;
      DBMS_OUTPUT.PUT_LINE('Loan ID: ' || loan_rec.loan_id);
      DBMS_OUTPUT.PUT_LINE('Customer ID: ' || loan_rec.customer_id);
      DBMS_OUTPUT.PUT_LINE('Loan Amount: ' || loan_rec.loan_amount);
      DBMS_OUTPUT.PUT_LINE('Due Date: ' || loan_rec.due_date);
      DBMS_OUTPUT.PUT_LINE('Loan Status: ' || loan_rec.loan_status);
      DBMS_OUTPUT.PUT_LINE('------------------------');
    END LOOP;
    CLOSE loan_cursor;
  END;
END;
