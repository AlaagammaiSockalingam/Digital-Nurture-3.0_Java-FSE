INSERT INTO customers (customer_id, name, date_of_birth)
VALUES (1, 'John Doe', TO_DATE('1950-01-01', 'YYYY-MM-DD'));

INSERT INTO customers (customer_id, name, date_of_birth)
VALUES (2, 'Jane Smith', TO_DATE('1960-06-15', 'YYYY-MM-DD'));

INSERT INTO customers (customer_id, name, date_of_birth)
VALUES (3, 'Bob Johnson', TO_DATE('1940-03-20', 'YYYY-MM-DD'));

INSERT INTO customers (customer_id, name, date_of_birth)
VALUES (4, 'Alice Brown', TO_DATE('1970-09-10', 'YYYY-MM-DD'));

INSERT INTO customers (customer_id, name, date_of_birth)
VALUES (5, 'Mike Davis', TO_DATE('1955-11-25', 'YYYY-MM-DD'));
SELECT * from customers;
INSERT INTO loans (loan_id, customer_id, interest_rate)
VALUES (1, 1, 6.5);

INSERT INTO loans (loan_id, customer_id, interest_rate)
VALUES (2, 2, 7.2);

INSERT INTO loans (loan_id, customer_id, interest_rate)
VALUES (3, 3, 5.8);

INSERT INTO loans (loan_id, customer_id, interest_rate)
VALUES (4, 4, 8.1);

INSERT INTO loans (loan_id, customer_id, interest_rate)
VALUES (5, 5, 6.9);
SELECT * from loans;

SET SERVEROUTPUT ON
DBMS_OUTPUT.ENABLE(NULL);
DECLARE
  v_customer_id customers.customer_id%TYPE;
  v_date_of_birth customers.date_of_birth%TYPE;
  v_interest_rate loans.interest_rate%TYPE;
  v_age NUMBER;

  CURSOR c_customers IS
    SELECT customer_id, date_of_birth
    FROM customers;

BEGIN
  OPEN c_customers;

  LOOP
    FETCH c_customers INTO v_customer_id, v_date_of_birth;
    EXIT WHEN c_customers%NOTFOUND;

    v_age := TRUNC(MONTHS_BETWEEN(SYSDATE, v_date_of_birth) / 12);

    IF v_age > 60 THEN
      SELECT interest_rate
      INTO v_interest_rate
      FROM loans
      WHERE customer_id = v_customer_id;

      UPDATE loans
      SET interest_rate = v_interest_rate - 1
      WHERE customer_id = v_customer_id;
      DBMS_OUTPUT.PUT_LINE('Applied 1% discount to customer ' || v_customer_id);
    END IF;
  END LOOP;

  CLOSE c_customers;
END;
