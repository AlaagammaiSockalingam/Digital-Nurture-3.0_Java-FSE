CREATE OR REPLACE PROCEDURE AddNewCustomer (
    p_customer_id   IN  NUMBER,
    p_name          IN  VARCHAR2,
    p_date_of_birth IN  DATE
)
IS
    v_err_msg   VARCHAR2(200);
BEGIN
    -- Step 1: Begin transaction
    SAVEPOINT start_tran;

    -- Step 2: Check if customer ID already exists
    SELECT COUNT(*)
    INTO   v_err_msg
    FROM   Customers
    WHERE  CUSTOMER_ID = p_customer_id;

    IF v_err_msg > 0 THEN
        v_err_msg := 'Customer with ID ' || p_customer_id || ' already exists.';
        INSERT INTO ERROR_LOG (ERROR_MESSAGE, ERROR_TIMESTAMP)
        VALUES (v_err_msg, SYSTIMESTAMP);
        RAISE_APPLICATION_ERROR(-20001, v_err_msg);
    END IF;

    -- Step 3: Insert new customer
    INSERT INTO Customers (CUSTOMER_ID, NAME, DATE_OF_BIRTH)
    VALUES (p_customer_id, p_name, p_date_of_birth);

    -- Step 4: Commit transaction
    COMMIT;

EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        v_err_msg := 'Customer with ID ' || p_customer_id || ' already exists.';
        INSERT INTO ERROR_LOG (ERROR_MESSAGE, ERROR_TIMESTAMP)
        VALUES (v_err_msg, SYSTIMESTAMP);
        RAISE_APPLICATION_ERROR(-20002, v_err_msg);
        
    WHEN OTHERS THEN
        v_err_msg := 'Error adding new customer: ' || SQLERRM;
        ROLLBACK TO SAVEPOINT start_tran;
        INSERT INTO ERROR_LOG (ERROR_MESSAGE, ERROR_TIMESTAMP)
        VALUES (v_err_msg, SYSTIMESTAMP);
        RAISE;
END AddNewCustomer;
/
-- Test with a new customer ID
BEGIN
    AddNewCustomer(1, 'John Doe', TO_DATE('1990-01-15', 'YYYY-MM-DD'));
END;
/

-- Test with an existing customer ID (should raise an error)
BEGIN
    AddNewCustomer(1, 'Jane Smith', TO_DATE('1985-06-20', 'YYYY-MM-DD'));
END;
/

-- Check the Customers table and ERROR_LOG table for results
SELECT * FROM Customers;
SELECT * FROM ERROR_LOG;
