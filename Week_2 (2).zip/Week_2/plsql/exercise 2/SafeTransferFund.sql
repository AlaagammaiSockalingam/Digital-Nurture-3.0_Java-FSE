CREATE OR REPLACE PROCEDURE SafeTransferFunds (
    p_from_account_id   IN  NUMBER,
    p_to_account_id     IN  NUMBER,
    p_amount            IN  NUMBER
)
IS
    v_from_balance  NUMBER(15,2);
    v_to_balance    NUMBER(15,2);
    v_err_msg       VARCHAR2(200);
BEGIN
    -- Step 1: Begin transaction
    SAVEPOINT start_tran;

    -- Step 2: Retrieve current balances
    SELECT BALANCE INTO v_from_balance
    FROM ACCOUNT
    WHERE ACCOUNTID = p_from_account_id;

    SELECT BALANCE INTO v_to_balance
    FROM ACCOUNT
    WHERE ACCOUNTID = p_to_account_id;

    -- Step 3: Check if from_account has sufficient balance
    IF v_from_balance < p_amount THEN
        v_err_msg := 'Insufficient funds in the source account.';
        RAISE_APPLICATION_ERROR(-20001, v_err_msg);
    END IF;

    -- Step 4: Perform the transfer
    UPDATE ACCOUNT
    SET BALANCE = BALANCE - p_amount
    WHERE ACCOUNTID = p_from_account_id;

    UPDATE ACCOUNT
    SET BALANCE = BALANCE + p_amount
    WHERE ACCOUNTID = p_to_account_id;

    -- Step 5: Commit transaction
    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        v_err_msg := 'Error during fund transfer: ' || SQLERRM;
        ROLLBACK TO SAVEPOINT start_tran;
        INSERT INTO ERROR_LOG (ERROR_MESSAGE, ERROR_TIMESTAMP)
        VALUES (v_err_msg, SYSTIMESTAMP);
END SafeTransferFunds;
/
-- Initial state of accounts
SELECT * FROM ACCOUNT;

-- Execute SafeTransferFunds procedure
BEGIN
    SafeTransferFunds(1, 2, 300);
END;
/

-- Check updated balances
SELECT * FROM ACCOUNT;

-- Check ERROR_LOG table (should be empty if no errors occurred)
SELECT * FROM ERROR_LOG;
-- Initial state of accounts
SELECT * FROM ACCOUNT;

-- Execute SafeTransferFunds procedure
BEGIN
    SafeTransferFunds(2, 1, 1000);
END;
/

-- Check updated balances
SELECT * FROM ACCOUNT;

-- Check ERROR_LOG table for the error message
SELECT * FROM ERROR_LOG;

